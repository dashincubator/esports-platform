/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DeleteHistory` (
  `createdAt` int(11) NOT NULL,
  `data` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Game` (
  `account` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `card` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `platform` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `totalActiveLadders` int(11) NOT NULL,
  `totalActiveLeagues` int(11) NOT NULL,
  `totalActiveTournaments` int(11) NOT NULL,
  `totalMatchesPlayed` int(11) NOT NULL,
  `totalPrizesPaid` int(11) NOT NULL,
  `totalWagered` int(11) NOT NULL,
  `view` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `platform` (`platform`),
  KEY `slug` (`slug`(191)),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `Game` VALUES ('playstation','1.jpg?m=1597772117','1.jpg?m=1586357410',1,'Call of Duty: Warzone',1,'warzone',0,0,0,0,325,0,'cod'),('activision','3.jpg?m=1597772123','3.jpg?m=1586357769',3,'Call of Duty: Modern Warfare',3,'modern-warfare',0,0,0,0,0,0,'cod'),('activision','5.jpg?m=1597772128','5.jpg?m=1587175210',5,'Call of Duty: Warzone',3,'warzone',0,0,0,0,220,0,'cod');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GameApiMatch` (
  `api` varchar(64) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `data` text NOT NULL,
  `endedAt` int(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startedAt` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`),
  UNIQUE KEY `id` (`id`),
  KEY `hash_2` (`hash`),
  KEY `api` (`api`,`username`),
  KEY `api_2` (`api`,`createdAt`,`startedAt`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GamePlatform` (
  `account` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `view` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`(191)),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `GamePlatform` VALUES ('playstation',1,'Playstation 4','ps4','playstation'),('xbox',2,'Xbox One','xbox-one','xbox'),('',3,'Cross Play','cross-play','cross-play'),('activision',4,'Cross Console','cross-console','cross-console');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ladder` (
  `endsAt` int(11) NOT NULL,
  `entryFee` decimal(10,2) NOT NULL COMMENT 'Per User',
  `entryFeePrizes` text NOT NULL,
  `firstToScore` int(11) NOT NULL,
  `format` varchar(60) NOT NULL,
  `game` int(11) NOT NULL,
  `gametypes` mediumtext NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info` mediumtext NOT NULL,
  `maxPlayersPerTeam` int(11) NOT NULL COMMENT 'Max Roster Size',
  `membershipRequired` tinyint(1) NOT NULL COMMENT '1 = Premium Required For Each User',
  `minPlayersPerTeam` int(11) NOT NULL COMMENT 'Min Roster Size',
  `name` varchar(255) NOT NULL,
  `organization` int(11) NOT NULL,
  `prizePool` decimal(10,2) NOT NULL,
  `prizes` mediumtext NOT NULL,
  `prizesAdjusted` tinyint(1) NOT NULL,
  `rules` mediumtext NOT NULL,
  `slug` varchar(255) NOT NULL,
  `startsAt` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = Registration Open, 1 = Registration Invite Only, 2 = Registration Closed',
  `stopLoss` int(11) NOT NULL,
  `totalLockedMembers` int(11) NOT NULL,
  `totalMatchesPlayed` int(11) NOT NULL,
  `totalRankedTeams` int(11) NOT NULL,
  `totalRegisteredTeams` int(11) NOT NULL,
  `totalWagered` int(11) NOT NULL,
  `type` mediumtext NOT NULL COMMENT 'Ladder, League, Survival, etc.',
  PRIMARY KEY (`id`),
  KEY `game` (`game`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LadderGametype` (
  `bestOf` text NOT NULL,
  `game` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mapsets` text NOT NULL,
  `modifiers` text NOT NULL,
  `name` text NOT NULL,
  `playersPerTeam` text NOT NULL,
  `teamsPerMatch` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `LadderGametype` VALUES ('[\"1\",\"3\",\"5\"]',3,1,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"],\"Search & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"],\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,2,'{\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Domination','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,3,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Hardpoint','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,4,'{\"Search & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Search & Destroy','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,6,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"],\"Sarch & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"],\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,7,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Hardpoint (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,8,'{\"Search & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Search & Destroy (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,9,'{\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Domination (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,10,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"],\"Search & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"],\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,11,'{\"Hardpoint\":[\"Azhir Cave\",\"Gun Runner\",\"Hackney Yard\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Hardpoint (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,12,'{\"Search & Destroy\":[\"Arklov Peak\",\"Gun Runner\",\"Piccadilly\",\"Rammaza\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Search & Destroy (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,13,'{\"Domination\":[\"Gun Runner\",\"Hackney Yard\",\"St. Petrograd\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','CDL Variant: Domination (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,14,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,15,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Search & Destroy','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,16,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Hardpoint','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,17,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Hackney Yard\",\"Vacant\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\",\"Hackney Yard\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,18,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Hackney Yard\",\"Vacant\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Search & Destroy (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,19,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\",\"Hackney Yard\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Hardpoint (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,20,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Hackney Yard\",\"Vacant\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\",\"Hackney Yard\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,21,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Hackney Yard\",\"Vacant\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Search & Destroy (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,22,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Arklov Peak\",\"Rammaza\",\"Hackney Yard\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GB Variant: Hardpoint (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,23,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,24,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Search & Destroy','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,25,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Hardpoint','[\"3\",\"4\",\"5\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,26,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,27,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Search & Destroy (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,28,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Hardpoint (Duos)','[\"2\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,29,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"],\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,30,'{\"CDL Search & Destroy\":[\"St. Petrograd\",\"Rammaza\",\"Gun Runner\",\"Crash\",\"Talsik Backlot\",\"Arklov Peak\",\"Vacant\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Search & Destroy (Singles)','[\"1\"]','[\"2\"]'),('[\"1\",\"3\",\"5\"]',3,31,'{\"CDL Hardpoint\":[\"Gun Runner\",\"St. Petrograd\",\"Azhir Cave\",\"Hackney Yard\",\"Rammaza\",\"Arklov Peak\"]}','[\"Controller Only\",\"Mouse & Keyboard Only\",\"Any Control Scheme\"]','GAMRS Variant: Hardpoint (Singles)','[\"1\"]','[\"2\"]');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LadderMatch` (
  `bestOf` int(11) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `gametype` int(11) NOT NULL,
  `hosts` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ladder` int(11) NOT NULL,
  `mapset` text NOT NULL,
  `modifiers` text NOT NULL,
  `playersPerTeam` int(11) NOT NULL,
  `startedAt` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = In Matchfinder, 1 = Upcoming, 2 = Playing, 3 = Complete, 4 = Disputed',
  `team` int(11) NOT NULL,
  `teamsPerMatch` int(11) NOT NULL COMMENT '# Of Teams In Match',
  `user` int(11) NOT NULL COMMENT 'Match Creator',
  `wager` decimal(10,2) NOT NULL COMMENT 'Per Player',
  `wagerComplete` int(11) NOT NULL,
  `winningTeam` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `ladder` (`ladder`),
  KEY `winningTeam` (`winningTeam`),
  KEY `team` (`team`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LadderMatchReport` (
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match` int(11) NOT NULL,
  `placement` int(11) NOT NULL,
  `reportedAt` int(11) NOT NULL,
  `roster` mediumtext NOT NULL,
  `team` int(11) NOT NULL,
  `user` int(11) NOT NULL COMMENT 'Reported By',
  PRIMARY KEY (`id`),
  KEY `match` (`match`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LadderTeam` (
  `avatar` text NOT NULL,
  `banner` text NOT NULL,
  `bio` varchar(255) CHARACTER SET utf8 NOT NULL,
  `createdAt` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `earnings` decimal(10,2) NOT NULL,
  `glicko2Rating` decimal(10,2) NOT NULL,
  `glicko2RatingDeviation` decimal(10,2) NOT NULL,
  `glicko2Volatility` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ladder` int(11) NOT NULL,
  `locked` tinyint(1) NOT NULL COMMENT '0 = Locked, 1 = Unlocked',
  `lockedAt` int(11) NOT NULL,
  `losses` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `scoreModifiedAt` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `wins` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ladder` (`ladder`),
  KEY `locked` (`locked`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LadderTeamMember` (
  `account` varchar(60) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `managesMatches` tinyint(1) NOT NULL,
  `managesTeam` tinyint(1) NOT NULL,
  `score` int(11) NOT NULL,
  `scoreModifiedAt` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = Team Invite, 1 = On Team',
  `team` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `team` (`team`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organization` (
  `createdAt` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `paypal` varchar(60) NOT NULL,
  `user` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `domain` (`domain`),
  KEY `id_2` (`id`),
  KEY `domain_2` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `Organization` VALUES (1590877275,'gamrs.net',1,'GAMRS','payments@gamrs.net',1),(1590877275,'latenightwarzone.co.uk',5,'LN Tournaments','info@latenighttournaments.co.uk',122),(1597092529,'esportsplus.net',7,'Dialed Up Games','temp@gmail.com',124);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tournament` (
  `bestOf` int(11) NOT NULL,
  `bestOfFinals` int(11) NOT NULL,
  `bracketGeneratedAt` int(11) NOT NULL,
  `bracketSize` int(11) NOT NULL,
  `entryFee` decimal(10,2) NOT NULL COMMENT 'Per User',
  `entryFeePrizes` text NOT NULL,
  `finalRound` int(11) NOT NULL,
  `game` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info` text NOT NULL,
  `mapsets` text NOT NULL,
  `membershipRequired` tinyint(1) NOT NULL,
  `modifiers` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `openBracketAt` int(11) NOT NULL,
  `openCheckinAt` int(11) NOT NULL,
  `openRegistrationAt` int(11) NOT NULL,
  `organization` int(11) NOT NULL,
  `playersPerTeam` int(11) NOT NULL,
  `prizePool` decimal(10,2) NOT NULL,
  `prizes` text NOT NULL,
  `prizesAdjusted` tinyint(1) NOT NULL COMMENT '0 = False, 1 = True',
  `rules` text NOT NULL,
  `slug` varchar(255) NOT NULL,
  `stopRound` int(11) NOT NULL,
  `teamsAdvancedPerMatch` int(11) NOT NULL,
  `teamsPerMatch` int(11) NOT NULL,
  `totalConfirmedTeams` int(11) NOT NULL,
  `totalRegisteredTeams` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `game` (`game`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TournamentGametype` (
  `bestOf` int(11) NOT NULL,
  `bestOfFinals` int(11) NOT NULL,
  `game` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mapsets` text NOT NULL,
  `modifiers` text NOT NULL,
  `name` text NOT NULL,
  `playersPerTeam` int(11) NOT NULL,
  `teamsPerMatch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TournamentMatch` (
  `group` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `round` int(11) NOT NULL,
  `startedAt` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = Upcoming, 1 = Playing, 2 = Complete, 3 = Disputed',
  `tournament` int(11) NOT NULL,
  `winningTeam` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tournament` (`tournament`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TournamentMatchReport` (
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match` int(11) NOT NULL,
  `placement` int(11) NOT NULL COMMENT 'Placement/Rank In Final Round',
  `reportedAt` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `user` int(11) NOT NULL COMMENT 'Reported By',
  PRIMARY KEY (`id`),
  KEY `tournaments_matches_teams_ibfk_1` (`match`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TournamentTeam` (
  `avatar` text NOT NULL,
  `banner` text NOT NULL,
  `bio` varchar(255) NOT NULL,
  `confirmedAt` int(11) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locked` int(11) NOT NULL COMMENT '0 = Locked, 1 = Locked',
  `lockedAt` int(11) NOT NULL,
  `losses` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `seed` int(11) NOT NULL,
  `slug` varchar(32) NOT NULL,
  `tournament` int(11) NOT NULL,
  `wins` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tournament` (`tournament`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TournamentTeamMember` (
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `managesMatches` int(11) NOT NULL,
  `managesTeam` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = Team Invite, 1 = On Team',
  `team` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user` (`user`),
  KEY `team` (`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `adminPosition` int(11) NOT NULL,
  `avatar` text NOT NULL,
  `banner` text NOT NULL,
  `bio` varchar(255) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locked` tinyint(1) NOT NULL COMMENT '0 = Unlocked, 1 = Locked',
  `lockedAt` int(11) NOT NULL,
  `membershipExpiresAt` int(11) NOT NULL,
  `organization` int(11) NOT NULL,
  `password` text NOT NULL,
  `signinToken` varchar(255) NOT NULL,
  `slug` varchar(32) NOT NULL,
  `timezone` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `wagers` tinyint(1) NOT NULL COMMENT '0 = Off, 1 = On',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `id_2` (`id`),
  KEY `slug_2` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `User` VALUES (1,'1.jpg?m=1586672921','','sfsdafadsfscdscsadcdsacs\r\nsfsdafadsfscdscsadcdsacs\r\nsfsdafadsfscdscsadcdsacs',1585876851,'icjr@gamrs.net',1,0,0,1593412196,1,'$2y$10$JVDoIKU1wutf1fqPwblTIuPEMtOXzyJ7zpdikGRYcoG95FHjmVPEi','a79ce726-2395-4d29-ba47-8533d3cf5795','icjr','America/Dawson','ICJR',0),(1,'','','',1585877271,'ryan@gamrs.net',2,0,0,1590733796,1,'$2y$10$Ox.1Vi6Odg6Iyyk5vgD9UubwQsB9x8uS2SOc8uVHiQ4oih8i.nwuS','f6a859fd-de77-4cd2-af48-73d346f6432d','minion','America/Indiana/Indianapolis','minion',0),(0,'','','',1585877503,'rharrell1996@gmail.com',3,0,0,0,1,'$2y$10$L/pCsjGAkw4a2PNDQhHoguTo9.Pz3KvvKKoVozSXVoIUvTrgtpl1m','7f99e5f6-fa4a-4160-a0a0-05ad7c30447d','ryan','America/Indiana/Indianapolis','ryan',0),(0,'7.jpg?m=1586376687','7.jpg?m=1586376691','Love to Vidja Game',1586196654,'davidlove1990@gmail.com',7,0,0,0,1,'$2y$10$Hdb/Bwo9P2OSB3FKuENNDO0YkRgwOvXyuMUyOSYjkdSqU9q2/Z5ma','013791e2-4730-4e4c-831c-3547498ae94a','mrcyllence','America/Indiana/Indianapolis','mrcyllence',0),(0,'','','',1586364033,'joeychrisharrell@gmail.com',8,0,0,1590733796,1,'$2y$10$GJ5pLqBOcGgzWUf33q6tpeHLGgZo0XmSQVKrpras0zjjkR8difAVO','a533df63-bcba-4920-9641-37abdb473ccb','the-me-remix','America/Indiana/Indianapolis','The_me_remix',0),(0,'9.jpg?m=1586372457','9.jpg?m=1586372468','',1586372169,'leocohiba@gmail.com',9,0,0,0,1,'$2y$10$/GwOMWp7J.PhF7QU/UzmhOexCkdmTVV68cn0lvrLeqgbnRnUWzDL6','92dad2fb-f0fd-4ebd-bca9-c11cfc3bd0cb','cohiva','America/Indiana/Indianapolis','CoHiVa',0),(0,'','','',1586381966,'infiniitymlg@gmail.com',10,0,0,0,1,'$2y$10$sNHcwbsrQt8FmnyppK9aZuvAESK2GKQU1/QM4GjJH5sD3BwOVMSte','36fc374d-3879-4256-84ec-3962ef4db004','mego','America/Los_Angeles','Mego',0),(0,'','','',1586386637,'temp@gmail.com',11,0,0,0,1,'$2y$10$Q65fUtF3m.M7bl67oAnS/.FedLIBhWsgO3ULCVSn3MkxKW5mCxpdS','019d520a-16b2-4637-8c8d-839f2a0368a9','temp','America/Dawson','TEMP',0),(0,'','','',1586392469,'Bswansongames@gmail.com',12,0,0,0,1,'$2y$10$LQ1kKYJb4hf0s.wfIylDXe1ZptSP4JfvTc/vLN07D7sd5bEi0R.kS','f4ea6d34-b6c5-45fa-87d4-22a47de65a67','the-benji','America/Indiana/Indianapolis','The_Benji',0),(0,'','','',1586396835,'evanizer12@gmail.com',13,0,0,1593412196,1,'$2y$10$wOU2VIvZwLfuTWZlzaz9D..crR5ZUG5sqIef3lE3iIuND5ndWd1QS','f868bd23-dc74-48fb-943c-6b5ac1a3336c','questron360','America/Indiana/Indianapolis','Questron360',0),(0,'14.jpg?m=1586477645','14.jpg?m=1586477783','I’m a Gamrs OG, been here since the beginning. I was #3 on the old Gamrs Leaderboards.',1586477176,'branhammatthew34@gmail.com',14,0,0,0,1,'$2y$10$wkwBm2uwm95lBh.qjtmQieHy5x0i0NzRSaS8YvB.Uk8WvowVg0v8.','a192135f-a9e1-4910-9d70-6d8312c6ea92','xmkb34x','America/Indiana/Indianapolis','xMKB34x',0),(0,'','','',1586484090,'jaralato@gmail.com',15,0,0,0,1,'$2y$10$9myEGvCCw1SaZdtzxhtByeFIzboEx9o.WZ5kWxJPcK1mC8jB0HSx6','2762b5ad-62e9-4fed-9815-8fd0b6c388a1','jake','America/Chicago','jake',0),(0,'','','',1586509887,'nxrdin@hotmail.com',16,0,0,0,1,'$2y$10$CrK11LmD6IJpzggHegY1DOTiWManarhuI1Ark7hu6b8I7hwGD/ydy','be79c78d-1c2b-4ece-8598-8236bf9d9c73','norry','Europe/Berlin','NORRY',0),(0,'','','',1586520466,'wooclan005@yahoo.com',17,0,0,0,1,'$2y$10$SOdqTWIYSvy4TbCz0dSwP.Z97Z1fUTBUIPpD4dki/W8OwVhlGmRVW','bfca7a8f-3c3e-4f05-83b8-1c092a9ea98f','itswoo','America/Indiana/Indianapolis','ItsWoo',0),(0,'','','',1586568875,'Madsenaustin@att.net',18,0,0,0,1,'$2y$10$dsF3HWo.9fQ5QVJstZkxq.GumJ3Fr0gIIhElTaC4lIvPCGRYv0coe','ab2fb232-f7d0-48c1-a31d-c2a37c87b8c4','austinmadsen','America/Indiana/Indianapolis','Austinmadsen',0),(0,'','','',1586569933,'temp2@gmail.com',19,0,0,0,1,'$2y$10$KxF6R7dlDzecxnxEYmJiMuRgmDnsN11LjVrXsSjgPRCnCped7Hon.','3c74c13d-d754-46d0-915c-3bff189f879a','temp2','America/Los_Angeles','Temp2',0),(0,'20.jpg?m=1586635452','','',1586635331,'oliverlarabjj@icloud.com',20,0,0,1593412196,1,'$2y$10$tf5Zp3GrB0A8dPr8z0MXdeshPCc3fKLNLpSQ5kQS1DViprK5e.auq','b240e94a-dd17-4958-9a5a-16891f3a683c','mr-oliver645','America/Indiana/Indianapolis','Mr_Oliver645',0),(0,'','','',1586657258,'ryannick13@comcast.net',21,0,0,1590733796,1,'$2y$10$T4ap9k3wIzNdPcg/7ecFqeonHUgvYYgB2KfI1C0XPmczfGinjDJ02','b55b1a32-f791-43df-8efb-9288b9ab3de6','rmx-gaming','America/Indiana/Indianapolis','rmx_gaming',0),(0,'','','The Next Level',1586665984,'Jricapenuelas1@gmail.com',22,0,0,1590733796,1,'$2y$10$SvPtchyf07C4BaDMIR4ZLuNY127sAW1NrLjvCmU3gq2lWEfkEM.JG','127710c7-d4a8-4ed5-8ea2-02be142b1898','sh0owtime','America/Indiana/Indianapolis','Sh0owTiMe',1),(0,'23.jpg?m=1586667419','','',1586667407,'psyfisciguy@yahoo.com',23,0,0,1590733796,1,'$2y$10$63oSyxRoC3pdptFnMM1WJOuc26Rr6J0wl65Z5fl.m0BAK3.1zACtK','df2426a5-50d4-45a9-92ec-24d87c0af9c2','terrorshahrk','America/Dawson','Terrorshahrk',1),(0,'','','',1586668040,'steveeramos09@gmail.com',24,0,0,1590733796,1,'$2y$10$mnwo0cickdGiUUv1VQwFguV1JWdKj/GiaIjmwN0oaPMSsLixFfLr6','bd487713-46b8-452d-bd5b-dc726b07b47e','soulstealer','America/Indiana/Indianapolis','Soulstealer',0),(0,'25.jpg?m=1586669759','25.jpg?m=1586673316','',1586669605,'passit-around@hotmail.com',25,0,0,1590733796,1,'$2y$10$hYZR4bYIvf.qVMcbEwFer.iZqi6kVPQMZcUgI6qBial5pWVtnBZGu','8f8a202b-eb84-46d4-8a65-8882668181dc','naturalluck','America/Dawson','NaturalLuck',0),(0,'26.jpg?m=1586692327','26.jpg?m=1586692318','',1586692307,'Xgoogglev3@gmail.com',26,0,0,0,1,'$2y$10$aPhK8HK8GcClDdNGlUxJdOhODLH6LJ7yyiUrRs1U6PrI3L6LZQ3n.','9341e27a-c95c-4349-b6fd-cff00c7aeca9','haitsgoogle','America/Dawson','Haitsgoogle',0),(0,'27.jpg?m=1586708714','','',1586708702,'meanz17@gmail.com',27,0,0,0,1,'$2y$10$7cJaXyELZ/q2G4sx1eM3o.juht9Ah2GNtHFRXTk/9mWPglwD13dU2','e16262d0-3ff8-43c1-9e47-5942b185e334','meanz17','America/Indiana/Indianapolis','Meanz17',0),(0,'','','',1586808782,'juliej@beyondthesummit.tv',28,0,0,0,1,'$2y$10$JWPdKntqLR5sZk.iSfWf4eO3zILAZxU01gjpLcNEdKvwea4tCBeka','497e243e-10d1-48b4-a162-740d34eca15d','juliventure','America/Los_Angeles','juliventure',0),(0,'','','',1587051950,'mahirulislam11@gmail.com',29,0,0,0,1,'$2y$10$7amnbgrW/1oFQO75GsAJJevek/Z5Vyeg4pVbgUJTGjIOtdSdYQV92','2a868a8d-6f7c-47f6-a5d4-fc0a7f740621','mithebeast','America/Indiana/Indianapolis','MITheBeast',0),(0,'','','',1587074906,'Chrishefner123@mail.com',30,0,0,0,1,'$2y$10$6udM6C.vAjVPFdok42jsD.LyoY97HFNcKFQhL7hlck9yQ5GanjlDm','141ba7b5-dda7-459e-ad2d-5bbe5e0cabff','chefner52','America/Indiana/Indianapolis','Chefner52',0),(0,'31.jpg?m=1589653514','','',1587177436,'Keegantolar12@hotmail.com',31,0,0,0,1,'$2y$10$usftPHW//nQnjzdiyv5W2.a/BAxVo2JBVt5UKy7jT1fXPzaZCPLJ.','e24365a4-6759-4c1e-854a-6353e09188f0','xeno','America/Denver','Xeno',1),(0,'','','',1587177463,'lugnut01@outlook.com',32,0,0,0,1,'$2y$10$aIK6BKIJve6fH./zsaCfq.RlfCDlqbsbCDSALMR3px.DowMz/HM9G','6ce5361e-c061-4223-87e6-9d070bdf6abd','zoults','America/Indiana/Indianapolis','Zoults',0),(0,'','','',1587177492,'Rafasoto707@gmail.com',33,0,0,0,1,'$2y$10$jwsbRSzcOwXO.XZVlpi6Ne4cgZV5sZmUv8.eK7RZJ4/gFMorRhgc6','29c6d517-20bc-441a-ac86-bce0750b2633','simia','America/Dawson','Simia',0),(0,'34.jpg?m=1587177544','','',1587177526,'akaiqwert84@gmail.com',34,0,0,0,1,'$2y$10$Ce4LtZpw/BkXyumOG8yJn.CGQou6y3ZxIaazvM0oQraWMnz0AYmii','68607372-7056-4d3b-8b01-d81998dd6bba','erosenjuva','America/Indiana/Indianapolis','EroSenjuVA',1),(0,'35.jpg?m=1587233188','35.jpg?m=1587233062','',1587177606,'brod121693@gmail.com',35,0,0,0,1,'$2y$10$nIAkbECBnwMOc5qED6AIounSztxCv76D3liJiPlz1jhWQ1E8ld4Ki','fd8561a8-ddd8-4be9-a6ea-963b73a573f5','sharpp','America/Indiana/Indianapolis','Sharpp',0),(0,'','','',1587177723,'Kalenq6@gmail.com',36,0,0,0,1,'$2y$10$VsDSAcrVoiDT.UOEbRjGLu6ABiSDo1k7Y/1ye/qyht9QHztcJJJUi','c47cdb82-58d5-4eec-82bf-078ca7c985dc','kkalem','America/Indiana/Indianapolis','KKalem',0),(0,'','','',1587177824,'hockeykid6442@yahoo.com',37,0,0,0,1,'$2y$10$V37R03HHG8i5C6ggeDvFnOi8IJWbGJxAnuA49/wTd.0Rg1vWdJ/Iy','3fc2300f-bc57-497b-a295-a9d5eccf9b65','hockeykid64','America/Indiana/Indianapolis','Hockeykid64',0),(0,'','','',1587177963,'Kalenq4@gmail.com',38,0,0,0,1,'$2y$10$.2X.h7SC0cWAZ/A6AFj7Xu567DSepqDgY3jLdI/sliJBhZkrBdBS2','d685d23c-9d35-401e-9877-c7213f338d15','kalen','America/Chicago','Kalen',0),(0,'','','',1587177995,'paulierivera99@gmail.com',39,0,0,0,1,'$2y$10$B8qFiwfCa2aOdKadMNVk0.ebxEvW64Tv7iTlagCErywcJDPX2ef9K','97a26595-cc1a-4c11-9e18-bfaca9939c36','privera','America/Dawson','privera',0),(0,'40.jpg?m=1587233462','40.jpg?m=1587233475','',1587178739,'austin.keeney@yahoo.com',40,0,0,0,1,'$2y$10$X0cxxwjdV3jKFb/RlpaVkubXFCsYheXe6uHhNuYtt08WGUNdO7vTu','524093ba-0c02-47cf-bddc-27c3c39278c8','arkeeney','America/Indiana/Indianapolis','Arkeeney',0),(0,'','','',1587180467,'itsgrat@gmail.com',41,0,0,0,1,'$2y$10$/DJCH3LcqW00cAUJU3K67OeEqoW.YdlHTm7BwKTVGlrNK6YDhARI.','6429a0f5-7d2b-487f-ba90-e258f8a0202f','bloo','America/Indiana/Indianapolis','bloo',1),(0,'','','',1587181715,'Thatguyflora@gmail.com',42,0,0,0,1,'$2y$10$y7.nqAVhOlPGPpRZ62mR2.cbzS.CKwqLPfJAmR/YAfziWEY8UGfTa','c8830255-6768-422c-8d61-843ad516fc98','flora','America/Indiana/Indianapolis','Flora',0),(0,'','','',1587181835,'Huggies267@gmail.com',43,0,0,0,1,'$2y$10$o47xFt7tcH9SHaNqNzDA4ODh427o8ZFBWmU550hsd2aAty/aRI7jK','097d3a27-0d1e-4259-a72d-22b7645b1b8a','trojanornah','America/Indiana/Indianapolis','TrojanOrNah',0),(0,'44.jpg?m=1587181871','44.jpg?m=1587181883','',1587181854,'Auston.holland12z@gmail.com',44,0,0,0,1,'$2y$10$9CC7p1t2mvgWNXxVfV.i4.2yE/rNFPtVhrOs82cQIhRrervGBv9/2','0e365410-dfd9-45ad-84e3-982c13810021','ominous','America/Chicago','OMINOUS',1),(0,'','','',1587181911,'Ronaldthroop35@yahoo.com',45,0,0,0,1,'$2y$10$dKaO1BvG4GcaZlz81yEVUOwJLSK.k77Z6o9asIwOcLw4QvolYNCtu','9237f17a-6a7c-4895-a9fd-784e55b7d29d','psych-szn','America/Indiana/Indianapolis','Psych-SZN',0),(0,'','','',1587182692,'jeff.ph0rmat@gmail.com',46,0,0,0,1,'$2y$10$tPIgnul2imgP9UlSBv7Sz.Z.7Hy923Ja8fV4A3JdeOTOHP4r7GObC','39fc097f-eea8-42a4-86ba-dcffca5e5753','ph0rmat','America/Dawson','ph0rmat',0),(0,'','','',1587183297,'Tristansepeda10@gmail.com',47,0,0,0,1,'$2y$10$NE5slSQ10v4iQw02Lz8K4.gmN7ACyytzFk80vDpn7t7jXXoM3j6GS','a66fae64-a002-42a7-aef8-9043793226e3','zeromonkey67','America/Chicago','Zeromonkey67',0),(0,'','','',1587194560,'Darrylpip@live.co.uk',48,0,0,0,1,'$2y$10$Yv0POzgE27RGQ8c78KpVo.IOHRM2oKLJcmRaGvbvSJ1A2dAxAhoDq','43cb8f1f-ab80-4a1b-ac05-53a72440882b','armarda1','Europe/Berlin','ARMARDA1',1),(0,'49.jpg?m=1587195664','','',1587195645,'dennis.paloks@gmx.de',49,0,0,0,1,'$2y$10$/FulTO03D3Q1L6lnXMG/O.uytVcJmODzmgHF5bsTZNb2gk4v9Hjia','d388b86c-2b08-4350-8de7-1749680adce4','switchitv','Europe/Budapest','SwitchiTV',0),(0,'50.jpg?m=1587214897','','',1587213691,'ragernoob98@gmail.com',50,0,0,0,1,'$2y$10$88L8XkFViiXgCGb2Iqje4OFjJzOOWJxPaGPyeP6VodFCHNN77c7fu','d88b2af5-5cf9-4bac-970d-7fcd01d94437','llrageyll','America/Indiana/Indianapolis','llRageyll',0),(0,'','','',1587214365,'bjoern-bordasch@web.de',51,0,0,0,1,'$2y$10$96T49.5eB/L8ObInB1jPCOBYYxIzF/b/NtQbXao.S3zZbJVrCjPEC','49d6a435-e977-4cbe-aba0-7969c3c582e5','sacerdi','Europe/Budapest','Sacerdi',0),(0,'','','',1587214754,'beckmichul@gmail.com',52,0,0,0,1,'$2y$10$q9smoqsTmDEFWCcfS072QOKl9ivJyVTRVLwWRUyLHgTCFoJVXU2oS','1be9b3ad-1a25-4bec-a8df-264edaf43a3b','defbeck','America/Indiana/Indianapolis','defBeck',0),(0,'53.jpg?m=1587221425','','',1587221359,'robertkurzweil@gmail.com',53,0,0,0,1,'$2y$10$D7iQUEtvY3RBqrgXmO9VQ.anOr9RI5XXfOuIVhOLX4lZGZJrGCKRu','9e3f4df3-a61e-425e-b433-6e15b0516992','ihoriizonx','Europe/Budapest','IHoRiiZoNx',1),(0,'','','',1587226403,'paytonmoses19@gmail.com',54,0,0,0,1,'$2y$10$2pHZmJqzBqdtnigmIEO/yuk5X4Sf2w53ENnIV1IIwuA5h7VUg4iG2','468650d5-90dc-4aca-8cda-e81a920253ce','floraized','America/Indiana/Indianapolis','Floraized',0),(0,'','','',1587227556,'benletch64@gmail.com',55,0,0,0,1,'$2y$10$YQ0kRHnE.iucJTkRvJC1SOglCE4kB2DY0PVCREv0LMV/qdDDQRzwO','4a646b0a-e88f-4c61-9b6f-a3493fce1ddb','benletch','America/Indiana/Indianapolis','benletch',0),(0,'','','',1587227789,'koberst54@gmail.com',56,0,0,0,1,'$2y$10$Q3rOoAzbw62wpktByHkM4eaddlYvCWu/Bq4GAT2kBM6DgOxZ9kCuu','4975a4f9-7890-46d5-aa41-fdf5568739b9','psycality','America/Chicago','Psycality',0),(0,'57.jpg?m=1587229998','','Content Creator for @KarnageClan',1587229986,'neslo@motiv8gaming.com',57,0,0,0,1,'$2y$10$GjCJCvaHC.rdv6kBzB7e5.d9hZpYBmlCFSVrbLcaE7kAmbv4Kn3wm','af312190-bfd2-4b3e-8ff5-69708848b27c','iamneslo','America/Indiana/Indianapolis','iamneslo',0),(0,'58.jpg?m=1587230590','58.jpg?m=1587230606','',1587230525,'ethensoutherland@gmail.com',58,0,0,0,1,'$2y$10$cCrls7nYTIMop5bfcjgk4.umpYN2zr3K0CU8tzukPsSGyMssw/Dmu','9655bcc9-303a-4b8e-9c55-f18e1040ff39','hypnozeph','America/Indiana/Indianapolis','HypnoZeph',0),(0,'59.jpg?m=1587231705','59.jpg?m=1587231733','',1587230782,'imaboutogoham@gmail.com',59,0,0,0,1,'$2y$10$RU7HovSLreEFJmHCQUGiruYKFV7mzPCpTC9B5f1aoss.ihTQkVeGO','d0b11035-ff77-414e-90c5-8d46fac28200','hamz','America/Indiana/Indianapolis','hamz',1),(0,'','','',1587232671,'rippergoldjdv@gmail.com',60,0,0,0,1,'$2y$10$L64DoZ.Zd9NYQ04DyXvVHullnOti1YbltQWtDWbVPWDETmT71PmDO','d8a4c73c-a477-4687-807b-93747ee683b2','ripper','America/Dawson','ripper',0),(0,'','','',1587232706,'walterrice34@gmail.com',61,0,0,0,1,'$2y$10$GK20QHO63S0Ckl.rRoIQGO2TO4GD7UI8RyxvKVd29PkcJTVywrXaG','d0741662-34d6-4565-b917-fed61df4cb4f','gunfect','America/Indiana/Indianapolis','Gunfect',0),(0,'','','',1587233969,'wargentv@gmail.com',62,0,0,0,1,'$2y$10$VR8Po.F4CdOaGYlhVaBNfeCtGyehdY4ZRSBxtd59sBXmZoH6YBy8y','0d7fd194-f171-4187-8fae-7b7abd47d4ed','levexttv','America/Indiana/Indianapolis','LevexTTV',0),(0,'','','',1587234390,'itsmatrixs@gmail.com',63,0,0,0,1,'$2y$10$y.JiVlKvYI5nNYLWdWA89uBYoLjLj8MlLFtkysy8EL.Mij/vs2FMa','01bc31ad-147e-4413-80e7-e1e1a9d77148','matrixs','America/Indiana/Indianapolis','Matrixs',0),(0,'','','',1587236652,'marvin112961@gmail.com',64,0,0,0,1,'$2y$10$gpegoapExCZM8Y4bgdRKo.khyaxGX3Nt/xWHZ9MmVK3EXMVYvWGUm','94b1b254-95ad-44e0-9f01-355488c7e012','mavert','America/Indiana/Indianapolis','Mavert',0),(0,'','','',1587408306,'jjmcnutt05@gmail.com',65,0,0,0,1,'$2y$10$UzCRZJ67hLMuimTQMd.4ZuniErXZwWnMqW1svkzb6mDL8QyH5fPpi','b45e54ad-f374-4047-9742-3e854685d51b','ttv-calfine05','America/Chicago','TTV.CALFINE05',0),(0,'66.jpg?m=1589649566','66.jpg?m=1589650178','',1587535526,'Jemsix17@gmail.com',66,0,0,0,1,'$2y$10$EtI9ArBx8iruVn7MYmriQ.LUIJ7oMMUzOayClHpNkPK3SSxTJUHdC','b8c6966a-2772-4d21-a0d5-c8ed4569b187','jem','America/Indiana/Indianapolis','Jem',1),(0,'67.jpg?m=1587913970','','',1587913919,'scrillaxking@gmail.com',67,0,0,0,1,'$2y$10$EqQApUjxW9kwsqnXU0ZpcO9h.p1.FSIq44FDvZfDTEax5lkfD9sFG','5156521d-58ca-40c3-ac0e-8c8bbfaeaf4d','scrillaxking','America/Halifax','ScrillaxKing',1),(0,'68.jpg?m=1588345909','68.jpg?m=1588345936','',1588345808,'dylob047@gmail.com',68,0,0,0,1,'$2y$10$irxhhsRhcxF/ISvPKaMqjO5df/owlgpVFAXAnmy2z.VbDKhY...4S','5761592c-e2cf-4f80-803c-520bdd7b53fa','dylan04','Pacific/Pago_Pago','Dylan04',0),(0,'69.jpg?m=1588456169','','',1588387432,'TheGodXcon@yahoo.com',69,0,0,0,1,'$2y$10$Wn9mpYnaH120gIdG0RKXpenKkHT80H/p56pZa1jVL.XOJYNwuw4j2','038d3d61-d65e-4b32-9a50-99c685ee44d0','johnnyyj','America/Denver','JohnnyyJ',0),(0,'70.jpg?m=1589653852','','',1588389597,'Jon.ortiz2014@gmail.com',70,0,0,0,1,'$2y$10$njRE39BVdDovDTG7U3SwHuMoIotvE8JbDcxk46SAD8EfH1u4vBXhK','5def2a7b-9774-4ede-9215-279268fafbaa','tfatal','America/Dawson','Tfatal',0),(0,'','','',1588389850,'Chrisearl308@gmail.com',71,0,0,0,1,'$2y$10$jLAuL0oCy9oWIwvMdiY82uJLxgqPqR1jdu29ZAsu52M.mzmYybq9K','a3dc1ed7-fd5a-4c18-b84e-f63a0f90954e','entxurage','America/Indiana/Indianapolis','Entxurage',0),(0,'','','',1588390798,'stevenababits@gmail.com',72,0,0,0,1,'$2y$10$hESICTL6BonPndfElbNU..mZLMxsnvZE1gxOkIh8amfJMQHOeKvgu','dfb42849-d809-4b4a-85df-fa0c2069ac92','ddirectt','America/Indiana/Indianapolis','DDirectt',0),(0,'73.jpg?m=1588392726','','',1588392714,'ohdwi1son@gmail.com',73,0,0,0,1,'$2y$10$Q.8CrTxxmyVz8YzEjR3nmuA5vD/PJSeAOpcSH3HVkKU339plCplCO','fc24abf1-bfbf-4e5b-b349-6fdedab41862','dwi1son','America/Chicago','DWi1son',0),(0,'','','',1588394693,'Wwechamp1123@outlook.com',74,0,0,0,1,'$2y$10$YxoAMYYk856DHxoDa3UnFO.NX1FBIuZkTM3sJiQX.KF.powNNAGRi','f4474f1d-49d7-436c-b8a8-754bd5d69549','reaper','America/Chicago','Reaper',0),(0,'75.jpg?m=1588442053','','',1588394836,'elijah_lawson4@aol.com',75,0,0,0,1,'$2y$10$b6yv.SOwXtZxtn5MotwXue7ctWrkp9LQkVzmzABMMejBZix9HcPUi','4d4c7c92-d77d-4d37-99b6-04e0a49b0c4d','iameiijah','America/Indiana/Indianapolis','IAmEiijah',0),(0,'76.jpg?m=1588432291','76.jpg?m=1588432317','',1588422137,'davidlsmith1313@hotmail.com',76,0,0,0,1,'$2y$10$HcHoFnaVE0V/rYRcuQQ3G.CUCvX6nX0nU9bv.PZgBgSC40cvDFfqu','a450cdcd-f297-412b-99eb-f9481f8c053e','saletic','America/Indiana/Indianapolis','Saletic',1),(0,'','','',1588440305,'thomas.callinan@hotmail.co.uk',77,0,0,0,1,'$2y$10$i6xhmvbZrnOd7S0nQ1tYv.6XiN2TKrE8f/Pfs1l7XuqQK.gMJa7h.','b288aeae-f57d-48ca-938b-f7cd6660a0ac','kurfuzzled','Europe/Jersey','kurfuzzled',0),(0,'','','',1588440819,'caseycjk3@gmail.com',78,0,0,0,1,'$2y$10$ALM3Pf9wO9/ZHXRhYnwvM.b/To/8JOcvBjSWMIuBWzuHeZbvPVkFi','b51f83c8-8bbd-4393-8d2f-3edae383b5b0','kertsmar','America/Indiana/Indianapolis','Kertsmar',0),(0,'','','',1588441050,'Zayar02@gmail.com',79,0,0,0,1,'$2y$10$7H8Tn9Z50ma5PQIDwpKfSOZ5yHkYeenYOMetglpzIqqaEzDFrCSre','fa856cb0-42c2-4464-8a64-cd70d68380e2','vitaliityy','America/Indiana/Indianapolis','Vitaliityy',0),(0,'','','',1588441991,'chan8896@gmail.com',80,0,0,0,1,'$2y$10$E/Wie9A328Py4vkrc.6dWuBcPYPYnLlpQN8IGyHPXqLqQRvGMM.62','181f695a-6cf5-4166-8859-b5891e2291b1','clutchbelk','America/Indiana/Indianapolis','ClutchBelk',0),(0,'','','',1588442284,'manuel_garza21@hotmail.com',81,0,0,0,1,'$2y$10$/8MxX9RVef5RTm0yqN4ohuFXkFtMox4LAwm.v4tDS5vEWMzyzbVRG','6b00c6e5-69a1-47ae-9ca6-4c284d677ab9','fallujahh','America/Indiana/Indianapolis','fallujahh',0),(0,'','','',1588442486,'zsarratori@icloud.com',82,0,0,0,1,'$2y$10$wxcok1.SJ6bG7zjD20S3o.qjXToo68wii8YKNRKlHEYFjQfdpCpW2','9e43b38c-cadc-4812-a245-1942b9866d76','omunch','America/Indiana/Indianapolis','oMunch',0),(0,'','','',1588443440,'huntup97@yahoo.com',83,0,0,0,1,'$2y$10$Q/qJXdx7QjpMx9YJ.JoIFOYrS2j35LDTdv6mmH8jQvjVC.bA98b4C','26fb21d9-50da-489e-a4fc-ba7dec26b410','huntup','America/Indiana/Indianapolis','huntup',1),(0,'','','',1588443509,'devvengrigg@gmail.com',84,0,0,0,1,'$2y$10$h5BwpdmYKSZfG7Z/u/1EgOU9OyS4V1N9R6jWONIf7nUnw7Yy8epqW','39c4671a-8723-4b20-a31e-32b4fc746ba8','optimals','America/Indiana/Indianapolis','Optimals',0),(0,'','','',1588610183,'mikailmitha@gmail.com',85,0,0,0,1,'$2y$10$VZz2JjfE/pRs9CZ.4.RVSu6HBntreeolXL5prB0gZp7ZkP6thGJpe','39872316-ef6c-407b-8696-84093ea2b90b','kamen','America/Indiana/Indianapolis','Kamen',0),(0,'86.jpg?m=1588875610','86.jpg?m=1588875620','',1588875599,'mrfantaastik@gmail.com',86,0,0,0,1,'$2y$10$TRYP.SboWwtLZFO7Yoi2nu014poTf/1mFEaJSPfLo/8X7pzHE2qOu','adde3ace-ae03-4b68-808f-97a97668254a','mrfantaastik','America/Dawson','MrFantaastik',0),(0,'','87.jpg?m=1589090062','',1589089775,'makaylamaulding7@icloud.com',87,0,0,0,1,'$2y$10$nOgCtt0Mj/NDkUhhzHnRVuwxbG4OP/FmYhZeVI0r1Zu.aestLk13.','45e3396d-16af-4b80-9651-e114648600d9','hazel','America/Chicago','Hazel',0),(0,'88.jpg?m=1589110983','','Belfast',1589110949,'jackcarsonbond@yahoo.com',88,0,0,0,1,'$2y$10$uXnx/plcEivvJdp77zrYbuIArWJXBiSjItWz5w6K9HAf7nrBIbknO','a12a1503-82db-4bbe-8fcc-0778496006fa','billionbond','Europe/Jersey','BillionBond',1),(0,'','','',1589316791,'Staffm4400@yahoo.com',89,0,0,0,1,'$2y$10$myQLXPSCPwRzijbQcFJIkuAtLk2aqQRpRVrf2.p77Wd0svGheAqBG','4dae7f81-bb8b-424c-b4c7-095119c45d01','mugz','America/Indiana/Indianapolis','Mugz',0),(0,'90.jpg?m=1589486459','90.jpg?m=1589486469','',1589486416,'BusinessIccy@gmail.com',90,0,0,0,1,'$2y$10$TDzrbTpJUpJM.hQfX8.cH.l4hM9qZRuls14OpYB8tE5oY9IpINpqG','5f7520d7-86e0-430a-b57c-bceef52975ed','justincase','America/Chicago','JustinCase',1),(0,'91.jpg?m=1589653223','91.jpg?m=1589653231','',1589513261,'10kpromo1@gmail.com',91,0,0,0,1,'$2y$10$0Qd7cBPjVYqFE2InCLqcHuIVyBVPv1BzE3.9RKXdvOkT1oCPnsEO.','47d9eed1-7f6a-4ddb-bdcf-6850537f436b','10kcaash','America/Indiana/Indianapolis','10kcaash',0),(0,'','','',1589576555,'icon_sk8er@hotmail.com',92,0,0,0,1,'$2y$10$xyMZM.fU2Z/87rDk4HkvX.MRPVT7kiXf7.GTwr70EMZ7Vie4Ce0OW','61e18809-7fde-43b6-859b-4facd0e733e5','mrnemz08','America/Dawson','MrNemz08',0),(0,'93.jpg?m=1589586011','','',1589585979,'na7ebot@icloud.com',93,0,0,0,1,'$2y$10$d609CK99Ab45V4j6.r7AyOqtjEhrUhy7MMlZCVWR5pDz1qCfJPgsG','d680c009-c2c9-4ff2-9391-38175dba494e','natebot','America/Indiana/Indianapolis','Natebot',1),(0,'94.jpg?m=1589586894','','',1589586783,'aaronshadow10@gmail.com',94,0,0,0,1,'$2y$10$p3/63Ygj5XzitxvQmqq56.Vr/ifbjlCAY3giLiGWG59TsbTNH7pb.','e6b710e3-0c9b-4e0a-a5ec-8153ff7034ad','krypetic','America/Indiana/Indianapolis','Krypetic',0),(0,'','','',1589588019,'SquidAK47@gmail.com',95,0,0,0,1,'$2y$10$A6.spetUMDJXTdDdJNLk/O6F9YQ6sJihIbQw2HnqH4pUjt/VCIG12','ab6a883a-7ab2-48dd-a497-9af1a386d961','luweey','America/Indiana/Indianapolis','Luweey',0),(0,'','','',1589599598,'shawnry6442@gmail.com',96,0,0,0,1,'$2y$10$4Ve1OXAq8/aeMPI91QRVOOEZi00FcqptLFFY/4f4GgVp84hh/b1MG','1228f135-152b-4f46-8173-632a8a453d9d','hockeykid','America/Indiana/Indianapolis','hockeykid',0),(0,'97.jpg?m=1589647223','97.jpg?m=1589647212','',1589601331,'theoceaneopz@gmail.com',97,0,0,0,1,'$2y$10$Xk1ozBCvn.oGQ10iWdt9j.jJ3FSlouamUtLxQ8xYQHpObQ7.rPN/.','73df97ed-a8d7-4229-8bc4-77998d91f5d9','theoceaneopz','America/Indiana/Indianapolis','TheOceaneOpz',0),(0,'98.jpg?m=1589650542','98.jpg?m=1589650562','',1589601798,'chrisaviles410@gmail.com',98,0,0,0,1,'$2y$10$h07BOTx2yCj0SG7I937A3.6w/QlbEEjL5zQQ3guzfVRmQTXmbkBdu','50d2b2d9-01b2-4f73-aa80-03b195c26c2f','fluffy','America/Indiana/Indianapolis','Fluffy',0),(0,'','','',1589603547,'faisalbitar7@gmail.com',99,0,0,0,1,'$2y$10$4SdDEwxeIa9tr7fnImuhfeoGrc.ciOZ68eS6.NhbhsqC5AYn70sNC','0bff344a-1b8f-4062-865d-fc2505779df2','beats','Europe/Helsinki','Beats',0),(0,'','','',1589605443,'JMcNab888@gmail.com',100,0,0,0,1,'$2y$10$jrA0Btx8AUyau0Q4v1VnyunSXECiWURWdL9Vx9ANMp0B.kmWw3K5C','4efb27b4-20fe-4f38-b05c-96c94251c898','bleedcubbieblue','America/Indiana/Indianapolis','BleedCubbieBlue',0),(0,'','','',1589610207,'jacobadkins@live.com',101,0,0,0,1,'$2y$10$eh.D6KbLlSCXwJVxOrqfuug7pPd9xVm8q0MLhVdKgj31lNt597RJq','fac6f862-07e4-4bd9-a7c0-bb50831a9f84','xfateless','America/Indiana/Indianapolis','xFateless_',0),(0,'','','',1589611076,'tommytomgaming.co@gmail.co',102,0,0,0,1,'$2y$10$LmTFBjXR7LcUu3vU0C7IjOpD1tkBF9LZw4OUToH6ZFLI/3Oor8Mb.','8e356ee2-d17f-4da3-918d-6152f0720741','tommytomgaming','America/Indiana/Indianapolis','TommyTomGaming',0),(0,'','','',1589620240,'joshuatrainham@gmail.com',103,0,0,0,1,'$2y$10$hBj6osR5EB2ILy7uHENQHOlvzYj7rMk9M7IJGBlV1mHJ.q.nCbHUS','99779549-c5fd-4703-8c2a-d66aed2e2e1f','odedicate','America/Indiana/Indianapolis','oDedicate',1),(0,'','','',1589634885,'jmythikz@gmail.com',104,0,0,0,1,'$2y$10$3d2fnv61mZ7g0HkCQ9C2cOdex8SxyRrEfH/I9wCj2Xw9yd.xVffZi','7049dd2d-5e1e-4065-a784-54acd8e5cce1','jmythikz','America/Chicago','JMythikz',0),(0,'105.jpg?m=1589648366','105.jpg?m=1589648370','',1589642805,'Nadidles@outlook.com',105,0,0,0,1,'$2y$10$P2a7LaIOON/WYuSAnLndk.cGyvaSOC3rbkZz0W/ZXmYIU1eF1HiW6','9cac9a9a-e697-4b1c-ae39-6898747126d7','proreborn','America/Indiana/Indianapolis','ProReborn',0),(0,'','','',1589642863,'codey.woodie@gmail.com',106,0,0,0,1,'$2y$10$j/7KOvqxWLlXr.9eVT2uMu8Jz1T39LN4PXEEIoMDfLS/hB8z3pana','7cd79044-9d1d-4eec-b681-9a26b53ecdee','icodeyaw','America/Indiana/Indianapolis','iCodeyAW',0),(0,'','','',1589646729,'elijahwebb01@outlook.com',107,0,0,0,1,'$2y$10$8OHyRpUwOm7X4meUh2CnreyqsWSZtLT1a3Sh1sH2b3hF3WRGn4a.e','eeed260c-e037-49fd-b10e-e07dbb41d1a3','fleeky','America/Indiana/Indianapolis','Fleeky',0),(0,'108.jpg?m=1589648128','','',1589647566,'theoneandonlylvl1@gmail.com',108,0,0,0,1,'$2y$10$nUu3FBNpXcYeVEjPgqZop.foQhX8uV4gxldllNWx5AxLwfF7ckpx2','0fc5a953-612a-424a-8e8b-02da57c0e969','mohrtown','America/Chicago','Mohrtown',0),(0,'','','',1589650075,'jared.walder@hotmail.com',109,0,0,0,1,'$2y$10$nkRP2AD1SNJDfGH.VR67cuIIm28g5S8cPywqKPuSjn4KwAdj1nI4S','236dffeb-28a4-4c7c-acdc-37a40f7aea1e','sparkythebigdog','America/Chicago','sparkythebigdog',0),(0,'','','',1589650928,'gabrielnramirez0729@gmail.com',110,0,0,0,1,'$2y$10$xy73VZoV7NZiZ7Gb81PiwO8HYtDwLSY1KQfc0/BhCEjBygQuyei3W','09800bdc-f2cc-4cae-ac79-a317540adc72','g-ramirez','America/Dawson','G__Ramirez',0),(0,'','','',1589651157,'gquinones2017@gmail.com',111,0,0,0,1,'$2y$10$zASBf79pypgfx4OYRSaWouiyrCJhodHcBvy7PYTglqb3FpUz2Boee','8e5bab43-023e-4760-aa33-beb9d9be0e8b','discoo','America/Dawson','Discoo',0),(0,'','','',1589651340,'boisvert.jsb@gmail.com',112,0,0,0,1,'$2y$10$NkT3TdnxyR42xM6NLi9/w.DWmGkE5jOx2XVk1vB0/tnSq7NxYcYZa','cf4e4b6c-c1cc-400d-ac03-13205f595e6c','dissrespek','America/Indiana/Indianapolis','Dissrespek',0),(0,'','','Trust the process',1589651731,'jamalsamaroo@gmail.com',113,0,0,0,1,'$2y$10$fvWmC5x/i5f6nJ.HVUeERuQPCk76Ru9rf2dpuQljOJaCIk3na9cDu','cc01e6ce-6726-4e07-9d40-23b8a2dc0ae6','cunningwhippet','America/Indiana/Indianapolis','Cunningwhippet',0),(0,'','','',1589651805,'fpsisiah@gmail.com',114,0,0,0,1,'$2y$10$uqkbufa4TPbcwmGThRyQtu1tQMuS4dq8Kl3k8f/ylCTH6Q2O3wR4q','bc39938c-27f7-4b0b-a60c-f92c18f2328b','akyeret','America/Chicago','akyeret',0),(0,'115.jpg?m=1589652008','','',1589651986,'daniel.carlsonx99@icloud.com',115,0,0,0,1,'$2y$10$QsUznqX0sK3dA1cLLijs/OMNluriptBgNbe.wEXAKq1AxiKP/qNvm','228d75ef-8319-4ee9-9e84-64a12f64da91','swolzen','America/Indiana/Indianapolis','Swolzen',0),(0,'','','',1589652126,'gamingguru10@gmail.com',116,0,0,0,1,'$2y$10$qEgEDhssq5h3lJ.QBmebUeclG/8aQf.spY8ARYJrstv0hgE1ZB46O','2a11e715-8167-4432-99c5-09a86c0947f4','tephlonic','America/Indiana/Indianapolis','tephlonic',1),(0,'','','',1589653067,'mcmanusr74@yahoo.com',117,0,0,0,1,'$2y$10$J/kHSj/7M3bLAd.zdUfJnuEbEqb9lMdzh71LTCcwYnxM99P2F0k5u','7bc6bdaa-dfdd-47fd-8e23-3b104c17800c','symperion','America/Indiana/Indianapolis','Symperion',0),(0,'','','',1589653192,'marjalonh@gmail.com',118,0,0,0,1,'$2y$10$x98VIvVh.oj5/xee5PkdY.M0z4k43FJcO6QNktlEUTjRTYYGUFvQS','b7d90820-6cb7-47ba-9248-27b84ccea5fa','palsy','America/Chicago','Palsy',1),(0,'119.jpg?m=1589665866','119.jpg?m=1589665918','',1589665842,'ithegreat24@outlook.com',119,0,0,0,1,'$2y$10$8p3RVuAgQW0w644FCm6Y6.zGIImdTIRF9GdtNyUxkWMqVQ3QX1AEi','6296b61c-65f5-40f8-a486-54d8003b1efa','feedzplayz','America/Chicago','Feedzplayz',0),(0,'','','',1589668984,'repine44@gmail.com',120,0,0,0,1,'$2y$10$JBoytv8./2UpHpXiqxl3y.mVTzVgIrYtZdgnpx4AmqgT7yGceudze','acef1dfa-b6a8-4e20-9dcd-259ca8a1e1df','twitchyplay','America/Indiana/Indianapolis','twitchyplay',0),(0,'','','',1590045408,'rabidvirus@gmail.com',121,0,0,0,1,'$2y$10$XXMVaUQYqPDhqRYRwu2FwuwyuDtgwvssXNTWS3kMlwoDjAnhrN0KG','0aa07f68-ed92-42d4-8dfd-053175a932bd','myth1calz','America/Indiana/Indianapolis','Myth1Calz',0),(3,'122.png?m=2591465128','122.jpg?m=1591465188','',1591464844,'info@latenighttournaments.co.uk',122,0,0,0,1,'$2y$10$AkMYjkH8B02zwOZT4qhc.eCauCV9j6XN9oBqEzuz3mbWm6c.SEQrm','88221cc9-8f2a-4c54-aa21-e353136e12c2','ln-tournaments','Europe/London','LN Tournaments',0),(0,'','','',1591609700,'kayaniraffay10@gmail.com',123,0,0,0,1,'$2y$10$uBED8r3zvjRPtEoazjDJEuXpzGmEP0Vv8.QjE0g4o.pkbevbVps5y','a55e47a6-5273-4321-acb8-3b77f4a1934b','raffia','America/Indiana/Indianapolis','raffia',0),(6,'','124.jpg?m=1591818620','',1591818215,'jim@dialedupgames.com',124,0,0,0,1,'$2y$10$PI7idbmxLNsM8stZccfJVejQKqmlIwCvU5Dfu7VRWvt1joQ9Pj8Pa','e0a87665-e99f-472d-8e72-7939970250df','dialedupgames','America/Indiana/Indianapolis','DialedUpGames',0),(0,'','','',1592591562,'tomo195@hotmail.co.uk',125,0,0,0,5,'$2y$10$Kx/F.J91gqCMXVqHfOFad.gASSQoVJQA6H.ewpt5djR5FxkGTLFL2','86ace093-d370-4c1d-9b9a-84d36eb9db6d','testlatenight','Europe/London','TestLateNight',0),(0,'126.png?m=1592872425','126.jpg?m=1592872554','',1592866546,'temp3@gmail.com',126,0,0,0,1,'$2y$10$7BAJx33Fw8nlF3VpIEe6KODZofD9wHdEelVY1pu/vHyA8aRjj5HRO','48d03f49-bbdb-407e-8fa1-c9af3d70dffa','mfam','America/Dawson','mfam',0),(0,'','','',1593279687,'RogueKnightAce@outlook.com',127,0,0,0,1,'$2y$10$ppl2BvjDZCqv8el3OKyJw.ylPkVHknjxJBI7LfYoyL6AWXjFIoJLG','204afd96-a85f-4112-832c-394b47f6bdd2','karito','America/Chicago','Karito',0),(0,'128.png?m=1593290421','','',1593280007,'mbautista0217@gmail.com',128,0,0,0,1,'$2y$10$65p76PldNwugfSrG76kzNuicl481ZlJVxMiHPpqg4cuA4NU9qKQlS','3946de39-f9f0-45a6-8f0e-ed6e02e6853b','prxfanity','America/Indiana/Indianapolis','Prxfanity',0),(0,'129.png?m=1593290031','','',1593282098,'KGartrell@nnu.edu',129,0,0,0,1,'$2y$10$eV50za3SPXyzHm.3dRdXEep7fwr8M94vP4MCKf6b6KsCwrUrJqab.','832dbe78-dc85-4a76-80db-6471e214f8d5','captainkirklg','America/Denver','CaptainKirkLG',0),(0,'','','',1593283392,'jaycue75@yahoo.com',130,0,0,0,1,'$2y$10$r3jQNaSQJfaHwfKAlsecKO8EZm8U4l6..yfsJsm69O7jm6lGsQFny','cf86814c-4b2d-444b-9bd8-cc918ceca745','jayy-iwnl','America/Dawson','Jayy-iwnl-',0),(0,'','','',1593284579,'harpertommy67@gmail.com',131,0,0,0,1,'$2y$10$O9F03BIDRm5KxDZ8yOyhluX19gKF07so1lu5UCN8kw9mL5miMCRK2','26598640-1c5a-47b9-a096-2fd9a3b53999','fade-warrior1239','Europe/London','Fade_Warrior1239',0),(0,'','','',1593286104,'alexhennessy11967@gmail.com',132,0,0,0,1,'$2y$10$7lASlnQoTx.Tc8eyi0YrzeWQptU6D3NlNUvBmwg.G32.maCnt7G8C','be721f5c-ab9d-4f76-b0fa-1bf85c29eba0','hennessy','America/Indiana/Indianapolis','hennessy',0),(0,'','','',1593286112,'xw4rp4thx@gmail.com',133,0,0,0,1,'$2y$10$HRU82/RBYiECypICDKTj6e4hZBxoF4aujr19uhsp32F5IJirZqide','2146b9dd-94f2-49ca-b87b-55fb92884255','sgtwarpath','America/Indiana/Indianapolis','SGTWarpath',0),(0,'134.png?m=1593290098','','',1593287657,'tieran999@gmail.com',134,0,0,0,1,'$2y$10$.7gBE4ECqapvDTRXGbpOF.L/5OKjjm9GD5EOLlZJR1Ki5WdXzLBjS','a1778304-976a-4082-ab6c-3f177201bd9e','tridon','America/Denver','Tridon',0),(0,'135.png?m=1593289796','135.jpg?m=1593289805','I shoot things',1593287711,'jamiehall11@googlemail.com',135,0,0,0,1,'$2y$10$JvrabpxfKUAZh/YI8B0nc.BJzpCp6NNvPAORkgSTLZQL6i0mGGSAu','e63cc57c-8751-4660-aa2c-53322b4cee16','paradoxapl','America/Indiana/Indianapolis','paradoxapl',0),(0,'','','',1593287735,'gaminggod1992@yahoo.com',136,0,0,0,1,'$2y$10$/nT4KCedEkOwGw3YtHjh3uefaEw.i/bW6oG/fJ7biAQZIP8m6wdem','4fc269f7-7147-4344-a95f-cfd04d70090b','superverycoolguy','America/Indiana/Indianapolis','SuperVeryCoolGuy',0),(0,'','','',1593288165,'rafaelcardenas2001@gmail.com',137,0,0,0,1,'$2y$10$1A0b5N2FYT6Y8HbxfcktMOjt/7pO61znRCgK8MM9H5z7VmY/dNfNO','2ab5b7fe-5d74-4896-b0fe-bb00e839d2d4','icu-craze','America/Dawson','icu_craze',0),(0,'','','',1593289792,'neonist17@yahoo.com',138,0,0,0,1,'$2y$10$G/j24gEtg54og6IldT118uvCIes6XWNNiqr6YJIF.cgUlqQE/TCq2','27b7bd10-83cb-464d-b189-cb7afecde6d8','neonist','America/Chicago','Neonist',0),(0,'','','',1593289798,'htyler1205@yahoo.com',139,0,0,0,1,'$2y$10$WXjbeTHw4y8X/./HhuiNdeqPqUt6FGZfEb3YEO0sDlphLXflc4gGC','2f622e59-1efb-4b97-ba43-00468082d617','htyler','America/Dawson','htyler',0),(0,'','','',1593289814,'dannywoods16@gmail.com',140,0,0,0,1,'$2y$10$Ln8WhOC1oqR7/gDklJOjueJ5PJUZQX0WOc8mGWh1t3OqV72m6TxQG','64cdae59-ad30-40ff-bee8-2c79587d8dde','daan1014','Europe/London','DaaN1014',0),(0,'','','',1593290846,'williamtrammell2001@gmail.com',141,0,0,0,1,'$2y$10$JYlLosuwGInE2OkjEhpAM.G2V/.m.UXpqIz9F3uur1HuKLemMFy7q','1b04f707-bbb9-4a9f-890e-ca867794d848','belatedwt','America/Chicago','BelatedWT',0),(0,'142.png?m=1593294452','142.jpg?m=1593294462','',1593294317,'TuanJkr05@gmail.com',142,0,0,0,1,'$2y$10$KLKSZUqr00946NRMcdrEu.1kL5wG01iPh5lcGHmzsDtwLlnLqbadi','2b2fe2a0-4ede-4f06-ab5a-be94e93e8eb2','cptaznwolf','America/Indiana/Indianapolis','CptAznWolf',0),(0,'','','',1593469986,'almightyymlg@gmail.com',143,0,0,0,1,'$2y$10$ALAvBw.4mMSZ4UgVyMWBtu6RS/xR.rQUJ4l5GYsTmI9gFSUFM6mCe','7f731706-a57e-4b11-84c1-357b19185259','almightytjm','America/Dawson','AlmightyTJM',0),(0,'','','',1595648206,'Justin_Kozar@hotmail.com',144,0,0,0,1,'$2y$10$UuBEICBMEICd31KYPTRfJO2tlLGcLaQPTbkcKik9V3Lx3kZeZJzv2','daedad2f-1add-47d8-9a6c-fb64ec641b9e','igiraffe','America/Denver','iGiraffe',0),(0,'','','',1596465270,'bitukove@gmail.com',145,0,0,0,1,'$2y$10$rsXNK7K2fljNDqnRaNVjB.J7eV/k74Ldv2jrhJSTEKhPoiUWaRTEG','a70f5ee3-9f29-4fb1-92f5-8b0b1bdd46c9','nova','Europe/Helsinki','Nova',0),(0,'146.png?m=1597715386','146.jpg?m=1597714992','',1597714848,'b.rice316@yahoo.com',146,0,0,0,1,'$2y$10$nCzAMgwJaUO95J.mcRiO7eUNI3hmc1XaivoG83HQ5atrlS9Nt3ebO','9cc2100c-5621-4ba7-8924-b31f93b6fbda','ztankin','America/Chicago','zTankiN',0),(0,'','','',1597715649,'MazerEvents@gmail.com',147,0,0,0,1,'$2y$10$/LAOamKyESp6GDy5C9dP1.df9qODFU2Pc7Bt3wgNXwhWxBLWRuCwm','746d8b02-d1d0-4828-9a8e-d1a65f0bfb07','mazerevents','America/Indiana/Indianapolis','MazerEvents',0),(0,'148.png?m=1597717163','148.jpg?m=1597717171','',1597717055,'bartonologistgaming@gmail.com',148,0,0,0,1,'$2y$10$lQ21wXnQ9ltNMPzpMe0qruuXewDD3v79n0TfhR6iTrLd3gwXyP.F2','0d59ff8d-950a-486c-adff-5e018632aa8b','bartonologist','America/Chicago','Bartonologist',0),(0,'149.png?m=1597717188','149.jpg?m=1597717192','',1597717134,'emjovbusiness@gmail.com',149,0,0,0,1,'$2y$10$OKYBwu8C0SElOOCMao02tupHR6Cff5OIDtcQ/rUo6I/FbsQJIsboS','b693c52d-2afd-466c-a533-712e76eabd63','emjov','America/Dawson','EmJov',1),(0,'150.png?m=1597717906','','',1597717157,'mandhami@hotmail.com',150,0,0,0,1,'$2y$10$MLFiwp2bLnFQCFyatv/qeeNfUqoO2Obi2x6.v2FM7.qpkQ.y62i8W','d2762c0f-6245-4049-9bb1-84ffd20e60d5','truumaniac','America/Denver','truumaniac',0),(0,'151.png?m=1597717565','151.jpg?m=1597717572','',1597717368,'Meaderob@kean.edu',151,0,0,0,1,'$2y$10$P7VkfLF4qxne3nPU0Nm7ouGwrxAghz8GEK3u5JjDmwm1b7/dwaDDG','db62ebae-db4e-4b30-aee3-723e7244d05b','skoal','America/Indiana/Indianapolis','Skoal',1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserAccount` (
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `user` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `UserAccount` VALUES (1588039291,9,'playstation',2,'ItsMinionLive'),(1588039291,10,'activision',7,'MrCyllence#7584944'),(1588039291,11,'facebook',7,'MrCyllence-100284638155361'),(1588039291,12,'playstation',7,'MrCyllence10'),(1588039291,13,'twitch',7,'mrcyllence'),(1588039291,14,'twitter',7,'mrcyllence'),(1588039291,15,'youtube',7,'mrcyllence'),(1588039291,16,'playstation',8,'the_mr_remix'),(1588039291,17,'playstation',11,'mattchub16'),(1588039291,18,'playstation',12,'the_benji97'),(1588039291,19,'playstation',13,'Questron360'),(1588039291,20,'playstation',14,'XEndowment'),(1588039291,21,'twitch',14,'XEndowment'),(1588039291,22,'twitter',14,'Endowment_'),(1588039291,23,'playstation',20,'Mr_Oliver645'),(1588039291,24,'playstation',21,'Zizi'),(1588039291,25,'activision',22,'Sh0owTiMe#4884172'),(1588039291,26,'playstation',22,'Sh0owTiMe'),(1588039291,27,'twitch',22,'Sh0owTiMe'),(1588039291,28,'activision',23,'TerrorShahrk#6553761'),(1588039291,29,'playstation',23,'TerrorShahrk'),(1588039291,30,'twitch',23,'TerrorShahrk'),(1588039291,31,'twitter',23,'TerrorShahrk'),(1588039291,32,'activision',24,'Soulstealer'),(1588039291,33,'playstation',24,'Soulstealrr_oB'),(1588039291,34,'twitch',24,'soul5tealer'),(1588039291,35,'activision',25,'NaturalLuck'),(1588039291,36,'playstation',25,'Natural__Luck'),(1588039291,37,'playstation',26,'Haitsgoogle'),(1588039291,38,'playstation',29,'MITheBeast'),(1588039291,39,'playstation',30,'Lantia_Destroyer'),(1588039291,40,'activision',31,'XenoIHI#3435110'),(1588039291,41,'playstation',31,'XenoIHI'),(1588039291,42,'twitter',31,'XenoIHI'),(1588039291,43,'activision',32,'Zoults#1102406'),(1588039291,44,'playstation',32,'Zoults--'),(1588039291,45,'twitch',32,'Zoults'),(1588039291,46,'twitter',32,'Zoults'),(1588039291,47,'activision',33,'Simia#9114215'),(1588039291,48,'playstation',33,'Pure_Simia'),(1588039291,49,'twitter',33,'SimiaCreates'),(1588039291,50,'activision',34,'EroSenjuVA#3128649'),(1588039291,51,'playstation',34,'Psycholipsy'),(1588039291,52,'twitch',34,'erosenjuva'),(1588039291,53,'twitter',34,'SenjuVA'),(1588039291,54,'youtube',34,'channel/UCnH3tWfZ0bWAdFkdHijdJFg?'),(1588039291,55,'activision',35,'Sharp#4757995'),(1588039291,56,'playstation',35,'UseCodeSharp'),(1588039291,57,'activision',38,'KKalen#3074581'),(1588039291,58,'playstation',38,'KKalen-'),(1588039291,60,'playstation',39,'PRLVERA'),(1588039291,62,'playstation',40,'Arkeeney'),(1588039291,63,'twitch',40,'Arkeeney'),(1588039291,64,'twitter',40,'Arkeeney'),(1588039291,65,'activision',41,'Bloo#4898092'),(1588039291,66,'twitch',41,'bloo'),(1588039291,67,'activision',42,'Floraa#9400538'),(1588039291,68,'activision',44,'ØMÑĪ#7424187'),(1588039291,70,'playstation',45,'Psych-SZN19'),(1588039291,71,'twitch',45,'Og_Psych'),(1588039291,72,'twitter',45,'Robbiethroop1'),(1588039291,73,'youtube',45,'P S Y C H'),(1588039291,74,'activision',46,'ph0rmat#4504910'),(1588039291,75,'twitch',46,'ph0rmat'),(1588039291,76,'twitter',46,'ph0rmat'),(1588039291,77,'activision',47,'Zeromonkey67'),(1588039291,78,'playstation',47,'Zero_monkey_67'),(1588039291,79,'twitch',47,'Zeromonkey67'),(1588039291,80,'twitter',47,'Zeromonkey67'),(1588039291,82,'facebook',48,'ARMARDA1'),(1588039291,83,'playstation',48,'ARMARDA1'),(1588039291,84,'twitch',48,'Armarda001'),(1588039291,85,'twitter',48,'ARMARDA1'),(1588039291,86,'activision',49,'SwitchiTV#1021844'),(1588039291,87,'playstation',49,'SwitchiTV'),(1588039291,88,'twitch',49,'SwitchiTV'),(1588039291,89,'twitter',49,'SwitchiTV'),(1588039291,90,'activision',50,'YT Ragey#2790889'),(1588039291,91,'playstation',50,'llRageyll'),(1588039291,92,'twitter',50,'zRagey'),(1588039291,93,'youtube',50,'Ragey'),(1588039291,94,'activision',51,'Sacerdi'),(1588039291,95,'activision',52,'Beck#5332059'),(1588039291,96,'playstation',52,'Becklmao'),(1588039291,97,'twitter',52,'Becklmao_'),(1588039291,98,'activision',53,'HoRiiZoN#4739641'),(1588039291,99,'activision',54,'JohnnySins#9707386'),(1588039291,100,'playstation',54,'Yotokami'),(1588039291,101,'activision',55,'Benny#4874267'),(1588039291,102,'playstation',55,'benletch-_-'),(1588039291,103,'twitch',55,'benletch'),(1588039291,104,'twitter',55,'benletchYT'),(1588039291,105,'youtube',55,'DPG benletch'),(1588039291,106,'activision',56,'Psycality#4614191'),(1588039291,107,'playstation',56,'Psycality'),(1588039291,108,'activision',57,'Neslo#4666408'),(1588039291,109,'playstation',57,'NesloJO'),(1588039291,110,'twitch',57,'Neslo'),(1588039291,111,'twitter',57,'Neslo'),(1588039291,112,'youtube',57,'IamNeslo'),(1588039291,113,'activision',59,'hamz#1065658'),(1588039291,114,'playstation',59,'hammytk'),(1588039291,115,'twitch',59,'hamz'),(1588039291,116,'twitter',59,'hamzz'),(1588039291,117,'youtube',59,'user/GTimABOUTtogoHAM'),(1588039291,118,'activision',60,'RippeR#7439715'),(1588039291,119,'playstation',60,'ripper-sai'),(1588039291,120,'twitch',60,'rippersai'),(1588039291,121,'twitter',60,'rippersai_'),(1588039291,122,'activision',61,'Gunfect#2635427'),(1588039291,123,'playstation',61,'Gunfect'),(1588039291,124,'activision',62,'LevexTTV#6805499'),(1588039291,125,'playstation',62,'Wargentv'),(1588039291,126,'activision',63,'Matrixs#2320872'),(1588039291,127,'playstation',63,'BMatrixs'),(1588039291,128,'activision',64,'Mavert-#1487759'),(1588039291,129,'playstation',64,'Mavert-'),(1588039291,130,'activision',65,'Ttv Calfine05'),(1588039291,131,'twitch',65,'Calfine05'),(1588060566,132,'xbox',23,'Terrorshahrk'),(1588345850,133,'activision',68,'Dylan04'),(1588345850,134,'xbox',68,'DylanTheGreat04'),(1588387460,135,'twitter',69,'JohnnyyJ'),(1588387460,136,'twitch',69,'JohnnyyJ'),(1588387460,137,'activision',69,'JohnnyyJ'),(1588387460,138,'playstation',69,'JohnnyyJ'),(1588389614,139,'activision',70,'Tfatal'),(1588389614,140,'playstation',70,'Tfatal-'),(1588389883,141,'twitter',71,'Entxurage'),(1588389883,142,'twitch',71,'Entxurage'),(1588389883,143,'activision',71,'ElevateEntxurage#2268695'),(1588389883,144,'playstation',71,'Entxurage'),(1588390833,145,'twitch',72,'ddirectt'),(1588390833,147,'playstation',72,'DDirectt'),(1588392765,148,'twitter',73,'DWilsonn_'),(1588392765,149,'twitch',73,'DWi1son'),(1588392765,150,'playstation',73,'Wheelsin'),(1588394741,151,'activision',74,'Reaper#2602023'),(1588395074,152,'activision',75,'IAmElijah-'),(1588395074,153,'playstation',75,'IAmEIijah-'),(1588422332,154,'twitter',76,'Saletic_'),(1588422332,155,'twitch',76,'Saletic_'),(1588422332,156,'playstation',76,'Saletics'),(1588422332,157,'xbox',76,'Saletic'),(1588432269,158,'activision',76,'Saletic_#1274117'),(1588440838,159,'activision',45,'Psych-SZN#9206556'),(1588440841,160,'activision',78,'Kertsmar#1097967'),(1588440851,162,'playstation',78,'Kertsmar'),(1588441097,163,'twitch',79,'Vitaliityy'),(1588441097,164,'activision',79,'Vitality#5750001'),(1588441097,165,'playstation',79,'oVitaliityy'),(1588441427,166,'activision',72,'Direct#7531201'),(1588441638,167,'xbox',74,'Reaper5078'),(1588441896,168,'activision',73,'TwitchDWi1son#4641289'),(1588442017,169,'activision',80,'ClutchBelk#7674763'),(1588442303,170,'activision',81,'fallujahh#1855233'),(1588442571,171,'activision',82,'oMunch#2682997'),(1588442571,172,'playstation',82,'mistalVlunch'),(1588443470,173,'twitter',83,'Basedmay31'),(1588443470,174,'activision',83,'Crushdoxy#3476823'),(1588443470,175,'playstation',83,'Crushdoxy'),(1588443528,176,'activision',84,'Optimals#9152698'),(1588461948,177,'twitter',78,'Kertsmarr'),(1588610206,178,'playstation',85,'KamenYT'),(1588875706,179,'twitter',86,'mrfantaastik'),(1588875706,180,'twitch',86,'mrfantaastik'),(1588875706,181,'activision',86,'MrFantaastik#6009444'),(1588875706,182,'playstation',86,'MrFantaastik'),(1589090039,183,'twitter',87,'byHazelbtw'),(1589090039,184,'twitch',87,'byhazelbtw'),(1589090039,185,'activision',87,'hazel#9498993'),(1589111020,186,'xbox',88,'BillionBond'),(1589576573,187,'activision',92,'MrNemz08'),(1589583170,188,'activision',2,'ItsMinionLive'),(1589585792,189,'activision',89,'mugzszn#5392099'),(1589585792,190,'playstation',89,'mugz-szn'),(1589585904,191,'activision',13,'Questron360#8320007'),(1589586064,192,'activision',93,'Nate#6413812'),(1589586064,193,'playstation',93,'Natebot-'),(1589586840,194,'activision',20,'Mr_Oliver645#3014496'),(1589586878,195,'twitter',94,'krypetic'),(1589586878,196,'twitch',94,'krypetic'),(1589586878,197,'activision',94,'Krypetic#6127649'),(1589586878,198,'playstation',94,'Krypetic'),(1589588137,199,'activision',95,'Luweey#7360688'),(1589588137,200,'playstation',95,'Luweeyy'),(1589601405,202,'twitter',97,'TheOceaneOpz'),(1589601405,203,'twitch',97,'TheOceaneOpz'),(1589601405,204,'youtube',97,'TheOceaneOpz'),(1589601405,205,'activision',97,'Oceane#3295994'),(1589601405,206,'playstation',97,'ThaOceaneOpz_'),(1589601405,207,'xbox',97,'TheOceaneOpz'),(1589603603,208,'twitter',99,'Beatswarzone'),(1589603603,209,'youtube',99,'Beats'),(1589605479,210,'twitch',100,'BleedCubbieBlue'),(1589605479,211,'playstation',100,'BleedCubbieBlue-'),(1589610289,212,'activision',14,'Endowment#5474352'),(1589610534,213,'activision',101,'xfateless#6785552'),(1589611153,214,'twitter',102,'TommyTomGaming'),(1589611153,215,'twitch',102,'TommyTomGaming'),(1589611349,216,'activision',102,'Tommy#6740112'),(1589620459,217,'twitter',103,'oDedicate_'),(1589620459,218,'twitch',103,'odedicate'),(1589620459,219,'activision',103,'Dedicate#9925109'),(1589620459,220,'playstation',103,'oDedicate-_-'),(1589634921,221,'activision',104,'JMythikz#3332515'),(1589634921,222,'playstation',104,'JMythikz-'),(1589642825,223,'activision',105,'ProReborn'),(1589642825,224,'xbox',105,'ProRebornn'),(1589642888,225,'activision',106,'Codey#9422350'),(1589642923,226,'playstation',106,'iCodeyAW'),(1589646806,228,'twitch',107,'ChippaDippa'),(1589646806,229,'activision',107,'Eli#1499541'),(1589646806,230,'playstation',107,'Flieky'),(1589646823,231,'twitter',107,'F1eeky'),(1589647775,232,'activision',108,'Mohrtown#2890698'),(1589648091,233,'twitter',108,'Mohrtown'),(1589648091,234,'twitch',108,'Mohrtown'),(1589648431,235,'twitter',105,'ProRebornYT'),(1589648431,236,'twitch',105,'ProRebornLive'),(1589648431,237,'youtube',105,'c/proreborn'),(1589648996,238,'activision',90,'JustinCase#2670222'),(1589649975,239,'activision',66,'Jem#8455888'),(1589649975,240,'playstation',66,'jemsix'),(1589650078,241,'activision',98,'Fluffy Is God#7213089'),(1589650091,242,'twitter',89,'mstaff44'),(1589650091,243,'twitch',89,'Mugz-szn'),(1589650095,244,'activision',109,'Sparkythebigdog#6896854'),(1589650164,245,'twitter',98,'FluffyiG'),(1589650164,246,'twitch',98,'FluffyiG'),(1589650164,247,'youtube',98,'FluffyiG'),(1589650164,248,'playstation',98,'Fluffyig'),(1589650164,249,'xbox',98,'Fluffy Is God'),(1589650948,250,'activision',110,'ramirez#4309285'),(1589651297,251,'activision',111,'Discoo#8349798'),(1589651400,252,'activision',112,'Dissrespek#2178346'),(1589651400,253,'playstation',112,'Itsdissrespek'),(1589651791,254,'activision',113,'Cunningwhippet#4284908'),(1589651850,255,'activision',114,'akyeret#5313844'),(1589651859,256,'playstation',114,'Akyeret'),(1589652063,257,'activision',115,'Swolzen#1840778'),(1589652063,258,'playstation',115,'Swolzen'),(1589652138,259,'activision',116,'teph#3529733'),(1589652217,260,'xbox',116,'tephlonic'),(1589652410,261,'activision',48,'ARMARDA1'),(1589653167,262,'activision',117,'Symperion#1442056'),(1589653167,263,'playstation',117,'Symperionn'),(1589653211,264,'twitter',91,'10kcaash'),(1589653211,265,'twitch',91,'TheWoahCreator'),(1589653211,266,'activision',91,'10k#6023841'),(1589653211,267,'xbox',91,'Wtf10k'),(1589653387,268,'activision',118,'Palsy#3156976'),(1589653387,269,'playstation',118,'PaIsy-'),(1589665893,270,'twitch',119,'Feedzplayz'),(1590831904,271,'discord',1,'CYbZV9G'),(1592591662,272,'activision',125,'TW#4178827'),(1592866631,274,'twitter',126,'nickmercs'),(1592866631,275,'youtube',126,'UCDvm7YoLE5r3ZZ6MWyD2vGQ'),(1592867540,276,'instagram',126,'nickmercs'),(1592868862,277,'discord',126,'nickmercs'),(1593280043,278,'activision',128,'Profanity#7087141'),(1593280043,279,'playstation',128,'Prcfanity'),(1593280043,280,'xbox',128,'Prcfanity'),(1593283518,281,'activision',130,'Vordakai'),(1593284651,282,'activision',131,'Vexity_Warrior#7313202'),(1593286282,284,'activision',132,'A3#5676054'),(1593286282,285,'xbox',132,'henny tanks'),(1593286303,286,'activision',133,'SGTWarpath#8494642'),(1593286303,287,'playstation',133,'SGT_Warpath'),(1593288382,288,'activision',137,'icuCraze#2273487'),(1593288382,289,'playstation',137,'iCU_Craze'),(1593289785,290,'activision',135,'TheRealParadox#3716317'),(1593289824,291,'discord',135,'Paradox#4081'),(1593289824,292,'twitter',135,'paradoxapl'),(1593289833,293,'activision',140,'DaaN1014#3778745'),(1593289834,295,'playstation',139,'htyler12'),(1593289841,296,'twitch',140,'DaaN1014'),(1593289849,297,'twitter',140,'DaaN1014'),(1593289864,298,'discord',138,'Neonist#7123'),(1593289864,299,'twitch',138,'neonist'),(1593289864,300,'activision',138,'TTVNeonist#1244090'),(1593289935,301,'activision',134,'Tridon#6086080'),(1593289947,302,'activision',136,'SuperVeryCoolGuy#3518905'),(1593289997,303,'activision',129,'CaptainKirkLG#3810472'),(1593290347,304,'activision',139,'tyler#7301253'),(1593290554,305,'activision',40,'arkeeney'),(1593290605,306,'activision',39,'Paul#6690578'),(1593290923,307,'activision',141,'BelatedWT#6152392'),(1593290923,308,'playstation',141,'BelatedWT'),(1593294436,309,'twitch',142,'CptAznWolf'),(1593294436,310,'youtube',142,'Azn Wolf'),(1593294436,311,'activision',142,'AznWolf-Yt#4961818'),(1593294436,312,'playstation',142,'LZX_Wolf-Yt'),(1593470004,313,'twitch',143,'almightytjm'),(1596465436,314,'facebook',145,'Witaliy Galix'),(1597714967,316,'twitter',146,'zTankin'),(1597714967,317,'twitch',146,'ztankin'),(1597714967,318,'activision',146,'zTankiN#2912397'),(1597714967,319,'playstation',146,'zTankiN'),(1597717165,320,'discord',149,'EmJov#5025'),(1597717165,321,'twitter',149,'EmJovBR'),(1597717165,322,'twitch',149,'EmJov'),(1597717165,324,'activision',149,'EmJov#5591468'),(1597717209,325,'activision',150,'truumaniac#8291170'),(1597717293,326,'activision',148,'Bartonologist#6381403'),(1597717301,327,'youtube',149,'UCDE8WfERKzcEAC9ImwngqVg'),(1597717484,328,'activision',151,'WuhanSkoal#7227279'),(1597717553,329,'twitter',151,'Skoal_GG'),(1597717953,330,'playstation',151,'FuzzOnTheSkoal');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserAdminPosition` (
  `createdAt` int(11) NOT NULL,
  `games` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `organization` int(11) NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `UserAdminPosition` VALUES (1581318655,'[1,3,5]',1,'Super Admin',1,'[\"manageLadders\",\"manageLadderGametypes\",\"manageGameTickets\",\"manageTournaments\",\"manageTournamentGametypes\",\"manageAdmin\",\"manageAdminPositions\",\"manageBankWithdraws\",\"manageGames\",\"manageGeneralTickets\",\"manageOrganizations\",\"owner\"]'),(1591465869,'[1,5]',3,'Warzone Organizer Permissions',5,'[\"manageLadders\",\"manageBankWithdraws\"]'),(1597092529,'[1,3,5]',6,'Site Owner',7,'[\"manageAdmin\",\"manageAdminPositions\",\"manageBankWithdraws\",\"manageAssignedGameTickets\",\"manageGames\",\"manageGameTickets\",\"manageAssignedGeneralTickets\",\"manageGeneralTickets\",\"manageLadders\",\"manageTournaments\"]');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserBank` (
  `balance` decimal(10,2) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `withdrawable` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `UserBank` VALUES (100.00,1591352846,2,1,20,100.00),(66.67,1591352846,3,1,13,66.67),(25.00,1591352846,4,1,22,25.00),(25.00,1591352846,5,1,24,25.00),(25.00,1591352846,6,1,25,25.00),(25.00,1591352846,7,1,101,25.00),(16.67,1591352846,8,1,8,16.67);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserBankDeposit` (
  `amount` decimal(10,2) NOT NULL,
  `chargeback` tinyint(1) NOT NULL COMMENT '0 = False, 1 = True',
  `createdAt` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) NOT NULL,
  `processedAt` int(11) NOT NULL,
  `processor` varchar(255) NOT NULL,
  `processorTransaction` text NOT NULL,
  `processorTransactionId` varchar(250) NOT NULL,
  `user` int(11) NOT NULL,
  `verifiedAt` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserBankTransaction` (
  `amount` decimal(10,2) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ladder` int(11) NOT NULL,
  `ladderMatch` int(11) NOT NULL,
  `memo` text NOT NULL,
  `refundedAt` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `tournament` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '0 = Credit (-), 1 = Debit (+)',
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserBankWithdraw` (
  `amount` decimal(10,2) NOT NULL,
  `createdAt` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) NOT NULL,
  `processedAt` int(11) NOT NULL,
  `processor` varchar(255) NOT NULL,
  `processorTransactionId` text NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_2` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserForgotPassword` (
  `code` text CHARACTER SET utf8 NOT NULL,
  `createdAt` int(11) NOT NULL,
  `emailedAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserLockMessage` (
  `content` mediumtext NOT NULL,
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `createdAt` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserLockMessageTemplate` (
  `content` mediumtext NOT NULL,
  `createdAt` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `createdAt` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserRank` (
  `earnings` decimal(10,2) NOT NULL,
  `game` int(11) NOT NULL,
  `glicko2Rating` decimal(10,2) NOT NULL,
  `glicko2RatingDeviation` decimal(10,2) NOT NULL,
  `glicko2Volatility` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `losses` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `score` decimal(10,2) NOT NULL,
  `scoreModifiedAt` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `wins` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `game` (`game`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTicket` (
  `assignedAt` int(11) NOT NULL,
  `assignedTo` int(11) NOT NULL,
  `category` text NOT NULL,
  `closedAt` int(11) NOT NULL,
  `closedBy` int(11) NOT NULL,
  `content` text NOT NULL,
  `createdAt` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ladderMatch` int(11) NOT NULL,
  `latestResponseAt` int(11) NOT NULL,
  `latestResponseBy` int(11) NOT NULL,
  `links` text NOT NULL,
  `organization` int(11) NOT NULL,
  `tournamentMatch` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `ladderMatch` (`ladderMatch`),
  KEY `tournamentMatch` (`tournamentMatch`),
  KEY `user` (`createdBy`),
  KEY `latestResponseBy` (`latestResponseBy`),
  KEY `assignedToAdmin` (`assignedTo`),
  KEY `uuid` (`uuid`(191)),
  KEY `closedByUser` (`closedBy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTicketResponse` (
  `content` text NOT NULL,
  `createdAt` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket` (`ticket`),
  KEY `user` (`createdBy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
